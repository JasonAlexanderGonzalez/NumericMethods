// Obtén todos los elementos con la clase "animado"
var elementosAnimados = document.querySelectorAll(".animado");

// Agrega el evento clic a cada elemento
elementosAnimados.forEach(function(elemento) {
  elemento.addEventListener("click", function() {
    // Agrega una clase adicional al elemento cuando se hace clic
    this.classList.add("animacion-personalizada");
  });
});
