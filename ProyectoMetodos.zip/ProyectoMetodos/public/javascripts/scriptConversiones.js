
function solveBisection() {
  var equationInput = document.getElementById("equation");
  var errorInput = document.getElementById("error");
  var resultDiv = document.getElementById("result");
  var inputA = document.getElementById("intervaloA");
  var inputB = document.getElementById("intervaloB");
  var iteraciones = document.getElementById("iteraciones");

  var equation = equationInput.value.trim();
  var error = parseFloat(errorInput.value);

  if (equation === "") {
    alert("Por favor, ingrese una ecuación.");
    return;
  }

  if (isNaN(error) || error <= 0) {
    alert("Por favor, ingrese una ecuacion válida.");
    return;
  }

  try {
    var f = math.compile(equation); // Compiling the equation
  } catch (error) {
    alert("La ecuación ingresada no es válida.");
    return;
  }

  // Clear previous results
  resultDiv.innerHTML = "";

  var table = document.createElement("table");
  table.innerHTML =
    "<tr><th>Iteración</th><th>a</th><th>b</th><th>c</th><th>f(a)</th><th>f(b)</th><th>f(c)</th><th>f(bx)*f(cx)</th><th>Error Est.</th><th>Error Abs.</th><th>Error Rel.</th></tr>";
  resultDiv.appendChild(table);

  // Lógica para ajustar los valores iniciales 'a' y 'b' dinámicamente
  var a = parseInt(inputA.value); // Valor inicial de 'a'
  var b = parseInt(inputB.value); // Valor inicial de 'b'

  const puntos = 100; // Cantidad de puntos a evaluar dentro del intervalo inicial
  const paso = (b - a) / puntos;
  for (let i = 0; i < puntos; i++) {
    const x = a + i * paso;
    const fa = f.evaluate({ x });
    const fb = f.evaluate({ x: b });

    if (fa * fb < 0) {
      a = x;
      break;
    }
  }

  var iteration = 0;
  var maxIterations = parseInt(iteraciones.value);// Número máximo de iteraciones
 
  while (iteration <= maxIterations) {
    var xReal = 1.189551235;
    var c = (a + b) / 2;

    var fa = f.evaluate({ x: a });
    var fb = f.evaluate({ x: b });
    var fc = f.evaluate({ x: c });
    var fbFc = fb * fc;

    var errorAbs = Math.abs(xReal - c);
    var errorEst = '-';
    var errorRel = errorAbs / Math.abs(xReal);

    var row = document.createElement("tr");
    row.innerHTML =
      "<td>" +
      iteration +
      "</td>" +
      "<td>" +
      a +
      "</td>" +
      "<td>" +
      b +
      "</td>" +
      "<td>" +
      c +
      "</td>" +
      "<td>" +
      fa +
      "</td>" +
      "<td>" +
      fb +
      "</td>" +
      "<td>" +
      fc +
      "</td>" +
      "<td>" +
      fbFc +
      "</td>" +
      "<td>" +
      errorEst +
      "</td>" +
      "<td>" +
      errorAbs +
      "</td>" +
      "<td>" +
      errorRel +
      "</td>";

    table.appendChild(row);
    if (errorAbs <= error) {
      break;
    }

    if (fc * fa > 0) {
      a = c;
    } else {
      b = c;
    }

    iteration++;
  }

  if (iteration > maxIterations) {
    alert(
      "El método de bisección no convergió después de " +
        maxIterations +
        " iteraciones. Por favor, revise su ecuación o elija un error más grande."
    );
  } else {
    alert("Puntos iniciales: a = " + a + ", b = " + b);
  }
}

function restrictLetterInput(input, letter) {
  // Obtener el valor actual del campo de entrada
  let value = input.value;

  // Eliminar cualquier carácter que no sea la letra permitida, números o caracteres especiales
  value = value.replace(new RegExp(`[^${letter}\\d\\W]`, "gi"), "");

  // Establecer el valor modificado nuevamente en el campo de entrada
  input.value = value;
}




